public class Animal {
  public float eat() {
    System.out.println("I am Eating");
    return 0;
  }
  public float walk(){
    System.out.println("I am Walking");
    return 0;
  }

}