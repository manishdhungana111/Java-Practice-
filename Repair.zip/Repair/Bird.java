public class Bird extends Animal {
  public int fly()
  {
    System.out.println("I am Flying");
    return 0;
  }

}